import { useState, useEffect } from "react";
import "./App.css";

// API URL
const API_URL = "https://api.jsonserve.com/Uw5CrX";

const App = () => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    const fetchQuizData = async () => {
      try {
        const response = await fetch(API_URL);
        if (!response.ok) {
          throw new Error("Failed to fetch quiz data.");
        }
        const data = await response.json();
        console.log("Fetched data:", data);  
        setQuestions(data);
      } 
        catch (error) {
        console.error(error.message);
      }
    };
    fetchQuizData();
  }, []);

  const handleAnswerSelect = (answer) => {
    const updatedAnswers = [...selectedAnswers];
    updatedAnswers[currentQuestionIndex] = answer;
    setSelectedAnswers(updatedAnswers);
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handleSubmit = () => {
    setShowResults(true);
  };

  const calculateScore = () => {
    return selectedAnswers.filter(
      (answer, index) => answer === questions[index].answer
    ).length;
  };

  const getAnswerClass = (option, index) => {
    if (showResults) {
      if (option === questions[index].answer) {
        return "correct";
      } else if (selectedAnswers[index] === option) {
        return "incorrect";
      }
    }
    return "";
  };


  return (
    <div className="quiz-container">
      {!showResults ? (
        <div>
          <h1>Quiz</h1>
          <div>
            <p>{questions[currentQuestionIndex]?.question}</p>
            {questions[currentQuestionIndex]?.options.map((option, index) => (
              <div key={index}>
                <input
                  type="radio"
                  id={option}
                  name="answer"
                  value={option}
                  checked={selectedAnswers[currentQuestionIndex] === option}
                  onChange={() => handleAnswerSelect(option)}/>
                <label htmlFor={option} className={getAnswerClass(option, currentQuestionIndex)}>
                  {option}
                </label>
              </div>
            ))}
          </div>

          <div>
            {currentQuestionIndex < questions.length - 1 ? (
              <button onClick={handleNext}>Next</button>

            ) : (

              <button onClick={handleSubmit}>Submit</button>
            )}
          </div>
        </div>
        
      ) : (

        <div>
          <h1>Quiz Results</h1>
          <p>Total Points: {calculateScore()} / {questions.length}</p>
          <ul>
            {questions.map((question, index) => (
              <li key={index}>
                <p>{question.question}</p>
                <p>Your answer: <span className={getAnswerClass(selectedAnswers[index], index)}>{selectedAnswers[index]}</span></p>
                <p>Correct answer: <span className="correct">{question.answer}</span></p>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default App;
